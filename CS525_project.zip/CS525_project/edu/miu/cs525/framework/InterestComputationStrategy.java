package edu.miu.cs525.framework;

public interface InterestComputationStrategy {
    double computeInterest(double accountBalance);
}

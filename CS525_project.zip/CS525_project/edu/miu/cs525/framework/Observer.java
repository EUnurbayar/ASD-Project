package edu.miu.cs525.framework;

public interface Observer {
    void update();
}

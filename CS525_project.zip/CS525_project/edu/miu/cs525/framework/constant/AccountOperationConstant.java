package edu.miu.cs525.framework.constant;

public enum AccountOperationConstant {
    DEPOSITED,
    WITHDRAW,
    REPORT,
    INTEREST,
};
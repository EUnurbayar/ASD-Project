package edu.miu.cs525.banking.utils;

public class ApplicationMessageConstant {

    public interface ExceptionMessage{
        public static final String INVALID_ACCOUNT_TYPE = "Invalid Account Type!";
    }
}

package edu.miu.cs525.banking.constant;

public class BankReportColumnConstant {
    public static String[] get() {
        return new String[] {
            "AccountNumber",
            "Name",
            "City",
            "Personal/Company",
            "Ch/S",
            "Amount"
        };
    }
}
